<?php
include("db.php");

function get_header(){
    include('nav.php');
}

function get_side(){
    include('sidebar.php');
}



?>