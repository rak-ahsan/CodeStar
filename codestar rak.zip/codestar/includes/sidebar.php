<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="../dist/css/style.css">
</head>
<div class="container-fluid d-flex justify-content-start gx-0 side">
    <div class="col-md-2 vh-100 text-white scrl" >
      <div class="side vh-100" style="background-color: #123456;">
      <a class = " nav-link p-3 aborder" style = "border-top:1px solid white" href="../index/index.php"><i class="fa-solid fa-gauge fa-xl me-3" style="color: #fcfcfc;"></i>
                    Dashboard </a>
      <a class = " nav-link p-3 aborder" href="../agent/agentadd.php">
        <i class="fa-regular fa-user fa-xl me-3"></i>
               Add New Agent</a>
      <a class = " nav-link p-3 aborder" href="../agent/agent.php"> 
        <i class="fa-solid fa-users-viewfinder fa-xl me-3"></i>View Agents</a>
      <a class = " nav-link p-3 aborder" href="#">
      <i class="fa-solid fa-money-bill-trend-up fa-xl me-3" style="color: #ffffff;"></i>
              Total Profit</a>
      <a class = "nav-link p-3 aborder" href="../property/propertyview.php">
      <i class="fa-solid fa-warehouse fa-xl me-3" style="color: #ffffff;"></i>
                Avaiable Property
      </a>
      <a class = "nav-link p-3 aborder" href="#">
      <i class="fa-solid fa-angles-right fa-xl me-3" style="color: #ffffff;"></i>
              Running Project</a>
      <a class = "nav-link p-3 aborder" href="#">
        <i class="fa-solid fa-arrows-down-to-people fa-xl me-3" style="color: #ffffff;"></i>
            Total Agent
      </a>
      <a class = "nav-link p-3 aborder" href="#">
      <i class="fa-solid fa-right-from-bracket fa-xl me-3" style="color: #ffffff;"></i>
      
      Log Out</a>
      </div>
    </div>